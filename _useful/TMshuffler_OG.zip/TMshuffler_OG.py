TM = ["Felix", "Ando", "Nina", "Fabio", "Ben", "Betsy", "Max", "Zhenya", "Mihael", "Mint", "Pauline", "Ceci"]

shuffle(TM)

for student in TM:
    print(student)