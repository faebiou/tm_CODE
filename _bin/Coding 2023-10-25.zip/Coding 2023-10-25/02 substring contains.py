s = "Hello"

print("e" in s)
print("ll" in s)
print("all" in s)
